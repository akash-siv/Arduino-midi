# BluetoothPS2Controller
- Author: Evan Kale
- Email: evankale91@gmail.com
- Web: ISeeDeadPixel.com
- Blog: evankale.blogspot.ca
- YouTube: youtube.com/EvanKale91

See a demo video here (and schematics):
https://www.youtube.com/watch?v=mt8uF9IblUU

- Turn a PS2 controller into a Bluetooth controller!

