MIDI LE FOR OSX
=======

Based on Apple's Sample Code fora Bluetooth LE Heart Rate Monitor this utility connects to devices offering the MIDI-BLE UDID/Characeteristic introduced in OSX/iOS and prints out the received "MIDI"-Packets in HEX. I am using this tool to monitor and debug incoming raw packets. It's just a quick hack at this point and at some point might be extended to route incoming MIDI Data to the IAC Bus for backwards compatibility to OSX 10.7+.

