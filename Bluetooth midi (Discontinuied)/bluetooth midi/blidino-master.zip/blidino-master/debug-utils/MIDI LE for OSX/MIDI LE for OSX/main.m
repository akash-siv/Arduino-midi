//
//  main.m
//  MIDI LE for OSX
//
//  Created by Matthias Frick on 08.10.2014.
//  Copyright (c) 2014 Matthias Frick. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
